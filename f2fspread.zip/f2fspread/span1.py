import xml.etree.ElementTree as ET
import json

# This script is now designed to identify all *unique structures*
# for EVERY tag in a large XML file.

def get_element_structure(element):
    """
    Recursively generates a "structural signature" for an element,
    focusing on tag names, attribute names, and unique child structures.
    This helps identify all unique data layouts.
    """
    structure = {'tag': element.tag}
    
    # Get a sorted list of attribute names (keys)
    if element.attrib:
        structure['attributes'] = sorted(element.attrib.keys())
    
    # Check if the element contains text
    text = element.text.strip() if element.text else None
    if text:
        structure['has_text'] = True

    # Recursively get unique child structures
    child_structures = {}
    for child in element:
        # Get the structure of the child
        child_structure = get_element_structure(child)
        
        # Use the child's tag name as a key to store one
        # representative structure. This groups all identical
        # children (like 16 <ra> tags) into one.
        if child.tag not in child_structures:
            child_structures[child.tag] = child_structure
    
    if child_structures:
        # We sort by tag name to make the final signature consistent
        structure['children'] = dict(sorted(child_structures.items()))
        
    return structure

def main():
    """
    Main function to parse the SPAN XML file and find all unique
    structures for EVERY tag.
    """
    # This path is a "raw" string (r'...') to handle Windows backslashes
    xml_file_path = r'C:\Users\PANKJ\Downloads\nsccl.20251024.i1\nsccl.20251024.i01.spn'
    
    # This dictionary will store all our findings.
    # The key will be the tag name (e.g., 'cc', 'pf', 'o')
    # The value will be a set() of all unique structural signatures found.
    all_unique_structures = {}
    
    total_elements_processed = 0
    
    print(f"--- Starting fast 'iterparse' on {xml_file_path} ---")
    print(f"--- Identifying all unique tags and their structures ---")
    
    try:
        # We use iterparse to get 'end' events for *all* elements
        context = ET.iterparse(xml_file_path, events=('end',))

        for event, element in context:
            total_elements_processed += 1
            
            # Get the tag name
            tag = element.tag
            
            # 1. Generate the structural signature for this element
            structure_dict = get_element_structure(element)
            
            # 2. Convert the signature to a string so it can be added to a set
            structure_string = json.dumps(structure_dict, sort_keys=True)
            
            # 3. Add this structure to our main dictionary
            if tag not in all_unique_structures:
                all_unique_structures[tag] = set()
                
            all_unique_structures[tag].add(structure_string)
            
            # 4. CRITICAL: Clear the element to free up memory
            # This is essential for parsing large files.
            element.clear()

        print(f"\n--- Finished parsing! Processed {total_elements_processed} total elements. ---")
        print(f"--- Found {len(all_unique_structures)} unique tag(s) in the file. ---")

        # --- Print the report of all unique structures ---
        print("\n\n--- Report of Unique Structures by Tag ---")
        
        if not all_unique_structures:
            print("No elements were found in the file.")
            return

        # Sort tags alphabetically for a clean report
        for tag in sorted(all_unique_structures.keys()):
            structures_set = all_unique_structures[tag]
            
            print(f"\n\n===============================================")
            print(f" Tag: <{tag}>")
            print(f" Found {len(structures_set)} unique structure(s) for this tag")
            print(f"===============================================")
            
            for i, structure_string in enumerate(structures_set):
                print(f"\n--- Structure #{i + 1} for <{tag}> ---")
                # Convert the string back to a dictionary for pretty-printing
                structure_dict = json.loads(structure_string)
                print(json.dumps(structure_dict, indent=2))
            

    except ET.ParseError as e:
        print(f"Error parsing XML: {e}")
        print("Please ensure the file is a valid XML document.")
    except FileNotFoundError:
        print(f"Error: File not found at '{xml_file_path}'")
        print("Please update the 'xml_file_path' variable in the script.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        print("This might happen if the file is empty or malformed.")

if __name__ == "__main__":
    main()

