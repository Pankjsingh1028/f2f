import xml.etree.ElementTree as ET
import json

# --- A small, sample XML content that mimics a SPAN file structure ---
# We create this so the script is runnable for demonstration.
# In a real scenario, you would delete this and use your actual file.
SAMPLE_XML_CONTENT = """
<spanRisk>
  <pointInTime date="2025-10-27" isSetl="1">
    <exchange acro="CME" name="Chicago Mercantile Exchange" />
  </pointInTime>
  
  <ccDef>
    <!-- 'cc' is Combined Commodity -->
    <cc c="CL" name="Crude Oil">
      <pfDef>
        <!-- 'pf' is Product Family -->
        <pf pfCode="LO" pfType="OOF" name="Crude Oil Options">
          <series s="202612" pe="202612">
            <!-- 'o' is Option, 'k' is Strike -->
            <o o="C" k="80.00">
              <riskArray>
                <ra v="120.50" />
                <ra v="90.25" />
                <ra v="-10.00" />
                <!-- ... 13 more risk values ... -->
              </riskArray>
            </o>
            <o o="P" k="80.00">
              <riskArray>
                <ra v="-15.00" />
                <ra v="45.75" />
                <ra v="110.00" />
                <!-- ... 13 more risk values ... -->
              </riskArray>
            </o>
          </series>
        </pf>
        <pf pfCode="CL" pfType="FUT" name="Crude Oil Futures">
          <series s="202601" pe="202601">
            <riskArray>
              <ra v="1500.00" />
              <ra v="750.00" />
              <ra v="-750.00" />
              <!-- ... 13 more risk values ... -->
            </riskArray>
          </series>
        </pf>
      </pfDef>
    </cc>
  </ccDef>
</spanRisk>
"""

def inspect_element(element, indent_level=0):
    """
    Recursively prints the tag, attributes, and text of an XML element.
    This is useful for "inspecting" the file structure.
    """
    indent = '  ' * indent_level
    
    # "element.tag" is the variable name you're looking for (e.g., "k", "o", "riskArray")
    tag = element.tag
    
    # "element.attrib" is a dictionary of its attributes (e.g., {"k": "80.00", "o": "C"})
    attributes = element.attrib
    
    print(f"{indent}Tag: {tag}")
    
    if attributes:
        print(f"{indent}  Attributes: {attributes}")

    # "element.text" is the content between the tags
    text = element.text.strip() if element.text else None
    if text:
        print(f"{indent}  Text: {text}")

    # Recurse for all child elements
    for child in element:
        inspect_element(child, indent_level + 1)

def parse_element_to_dict(element):
    """
    Recursively converts an XML element and its children into a
    Python dictionary. This is the most flexible way to extract data.
    """
    result = {}

    # Store attributes in a sub-dictionary (using '@' is a common convention)
    if element.attrib:
        result['@attributes'] = element.attrib

    # Store text content (using '#' is a common convention)
    text = element.text.strip() if element.text else None
    if text:
        result['#text'] = text

    # Process child elements
    for child in element:
        child_tag = child.tag
        child_data = parse_element_to_dict(child)

        if child_tag not in result:
            # First time seeing this tag, add it as a key
            result[child_tag] = child_data
        else:
            # Tag already exists, so we have a list of items
            if not isinstance(result[child_tag], list):
                # Convert existing single item to a list
                result[child_tag] = [result[child_tag]]
            
            # Add the new item to the list
            result[child_tag].append(child_data)

    # If the element only has text, just return the text
    if not result and text:
        return text
    
    # If the element has attributes but no children or text, just return attributes
    if not result and element.attrib:
        return {'@attributes': element.attrib}

    return result

def main():
    """
    Main function to parse the SPAN XML file.
    """
    # --- IMPORTANT ---
    # This path has been fixed by adding an 'r' at the beginning.
    # This creates a "raw" string, which tells Python to ignore backslashes.
    xml_file_path = r'C:\Users\PANKJ\Downloads\nsccl.20251024.i1\nsccl.20251024.i01.spn'
    
    # --- Demonstration Code Removed ---
    # I've removed the code that creates the dummy 'span_file.xml'
    # so the script will now parse your actual file path.

    try:
        # Parse the XML file
        tree = ET.parse(xml_file_path)
        root = tree.getroot()

        # --- Option 1: Inspect the file structure ---
        print("\n--- Inspecting XML Structure ---")
        print("This shows every tag and attribute it finds.")
        inspect_element(root)

        # --- Option 2: Convert the entire file to a dictionary ---
        print("\n\n--- Extracting XML to Dictionary ---")
        print("This converts the whole file into a Python dictionary.")
        data_dict = parse_element_to_dict(root)
        
        # Pretty-print the dictionary using json module
        print(json.dumps(data_dict, indent=2))
        
        # --- How to access the data ---
        print("\n\n--- Example: Accessing Data from the Dictionary ---")
        try:
            # This path is based on our SAMPLE_XML_CONTENT
            # You would change this based on your file's structure
            first_option = data_dict['ccDef']['cc']['pfDef']['pf'][0]['series']['o'][0]
            print(f"First option data: {first_option}")
            
            first_option_strike = first_option['@attributes']['k']
            first_option_type = first_option['@attributes']['o']
            
            # --- FIX ---
            # The risk value 'v' is an *attribute* of the 'ra' tag, not its text.
            # So we access it through '@attributes', not '#text'.
            first_risk_value = first_option['riskArray']['ra'][0]['@attributes']['v']
            
            print(f"  Strike ('k'): {first_option_strike}")
            print(f"  Type ('o'): {first_option_type}")
            print(f"  First Risk Value ('v'): {first_risk_value}") # Changed label to 'v'
        
        except KeyError as e:
            print(f"Could not access sample data, structure might be different: {e}")
        except TypeError as e:
            print(f"Could not access sample data (check for lists/indices): {e}")


    except ET.ParseError as e:
        print(f"Error parsing XML: {e}")
        print("Please ensure the file is a valid XML document.")
    except FileNotFoundError:
        print(f"Error: File not found at '{xml_file_path}'")
        print("Please place your actual SPAN XML file in this directory and")
        print("update the 'xml_file_path' variable in the script.")

if __name__ == "__main__":
    main()


